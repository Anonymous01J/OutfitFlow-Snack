---
title: OutfitFlow
emoji: 🦀
colorFrom: blue
colorTo: yellow
sdk: docker
pinned: false
license: apache-2.0
short_description: REST API for resizing and background removal in garments
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
